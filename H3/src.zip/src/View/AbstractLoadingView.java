package View;

public interface AbstractLoadingView {
	void loadData();
	void saveData();
}
