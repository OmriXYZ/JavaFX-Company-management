package View;

public interface AbstractElectionMenuView {

}
